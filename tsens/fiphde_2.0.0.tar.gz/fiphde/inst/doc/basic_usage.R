## ---- include = FALSE---------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  eval=TRUE,
  warning=FALSE,
  message=FALSE,
  comment = "#>",
  fig.width=6, fig.height=4
)
options(rmarkdown.html_vignette.check_title = FALSE)

## ---- echo=FALSE--------------------------------------------------------------
# Load precooked results. See data-raw/generate_sysdata.R for details

# TSENS
hosp <- fiphde:::vd$hosp
prepped_hosp <- fiphde:::vd$prepped_hosp
prepped_hosp_tsibble <- fiphde:::vd$prepped_hosp_tsibble
hosp_fitfor <- fiphde:::vd$hosp_fitfor
formatted_list <- fiphde:::vd$formatted_list

# CREG
ilidat <- fiphde:::vd$ilidat
ilifor <- fiphde:::vd$ilifor
res <- fiphde:::vd$res
res$forecasts$location <- "15"

## ---- eval=FALSE, echo=FALSE, include=FALSE, message=FALSE, warning=FALSE-----
#  devtools::install(build_vignettes = TRUE, upgrade = FALSE)
#  vignette("basic_usage", package="fiphde")

## ----setup--------------------------------------------------------------------
library(fiphde)
library(dplyr)
library(purrr)
library(readr)
library(ggplot2)
theme_set(theme_bw())

## ---- eval=FALSE--------------------------------------------------------------
#  hosp <- get_hdgov_hosp(limitcols = TRUE)

## -----------------------------------------------------------------------------
hosp

## ---- eval=FALSE--------------------------------------------------------------
#  # Prep data
#  prepped_hosp <-
#    hosp %>%
#    prep_hdgov_hosp(statesonly=TRUE, min_per_week = 0, remove_incomplete = TRUE) %>%
#    dplyr::filter(abbreviation != "DC")

## -----------------------------------------------------------------------------
prepped_hosp

## -----------------------------------------------------------------------------
prepped_hosp %>% 
  filter(abbreviation %in% c("US", "CA", "TX", "NY")) %>% 
  ggplot(aes(week_end, flu.admits)) + geom_line() + 
  facet_wrap(~abbreviation, scale="free_y")

## -----------------------------------------------------------------------------
prepped_hosp %>% 
  filter(abbreviation!="US") %>% 
  filter(week_start>="2021-07-01" & week_end<"2022-06-30") %>% 
  group_by(abbreviation) %>% 
  summarize(total.flu.admits=sum(flu.admits)) %>% 
  arrange(desc(total.flu.admits)) %>% 
  head(10) %>% 
  knitr::kable(caption="Top 10 states with highest flu hospitalizations in 2021-2022.")

## ---- eval=FALSE--------------------------------------------------------------
#  prepped_hosp_tsibble <- make_tsibble(prepped_hosp,
#                                       epiyear=epiyear,
#                                       epiweek=epiweek,
#                                       key=location)

## -----------------------------------------------------------------------------
prepped_hosp_tsibble

## ---- eval=FALSE--------------------------------------------------------------
#  hosp_fitfor <- ts_fit_forecast(prepped_hosp_tsibble,
#                                 horizon=4L,
#                                 outcome="flu.admits",
#                                 trim_date = "2021-01-01",
#                                 covariates=TRUE,
#                                 models=list(arima='PDQ(0, 0, 0) + pdq(1:2, 0:2, 0)',
#                                             ets='season(method="N")',
#                                             nnetar=NULL),
#                                 ensemble=TRUE)

## -----------------------------------------------------------------------------
hosp_fitfor

## ---- eval=FALSE--------------------------------------------------------------
#  formatted_list <- format_for_submission(hosp_fitfor$tsfor, method = "ts", format = "legacy")

## -----------------------------------------------------------------------------
formatted_list

## ---- eval=FALSE--------------------------------------------------------------
#  validate_forecast(formatted_list$ensemble)

## -----------------------------------------------------------------------------
plot_forecast(prepped_hosp, formatted_list$ensemble, loc="US", pi = .5)
plot_forecast(prepped_hosp, formatted_list$ensemble, loc="36", pi = .5)
plot_forecast(prepped_hosp, formatted_list$ensemble, loc="12", pi = .5)

## -----------------------------------------------------------------------------
hosp_fitfor$tsfit$arima %>% 
  map("fit") %>% 
  map_df("spec") %>% 
  mutate(location = hosp_fitfor$tsfit$location, .before = "p")

## ---- eval=FALSE--------------------------------------------------------------
#  ilidat <-
#    get_cdc_ili(region=c("state"), years=2019:2022) %>%
#    filter(region == "Hawaii") %>%
#    replace_ili_nowcast(., weeks_to_replace=1)
#  
#  ilifor <- forecast_ili(ilidat, horizon=4L, trim_date="2020-03-01")

## -----------------------------------------------------------------------------
ilidat <- ilidat %>% mutate(weighted_ili=mnz_replace(weighted_ili))

ilifor$ilidat <- ilifor$ilidat %>% mutate(ili=mnz_replace(ili))
ilifor$ili_future <- ilifor$ili_future %>% mutate(ili=mnz_replace(ili))
ilifor$ili_bound <- ilifor$ili_bound  %>% mutate(ili=mnz_replace(ili))

## -----------------------------------------------------------------------------
dat_hi <-
  prepped_hosp %>%
  filter(abbreviation=="HI") %>%
  dplyr::mutate(date = MMWRweek::MMWRweek2Date(epiyear, epiweek)) %>%
  left_join(ilifor$ilidat, by = c("epiyear", "location", "epiweek")) %>%
  mutate(ili = log(ili))
dat_hi

## -----------------------------------------------------------------------------
models <-
  list(
    poisson = trending::glm_model(flu.admits ~ ili + hosp_rank + ili_rank, family = "poisson"),
    quasipoisson = trending::glm_model(flu.admits ~ ili + hosp_rank + ili_rank, family = "quasipoisson"),
    negbin = trending::glm_nb_model(flu.admits ~ ili + hosp_rank + ili_rank)
  )
models$poisson
models$quasipoisson
models$negbin

## -----------------------------------------------------------------------------
new_cov <-
  ilifor$ili_future %>%
  left_join(fiphde:::historical_severity, by="epiweek") %>%
  select(-epiweek,-epiyear) %>%
  mutate(ili = log(ili))
new_cov

## ---- eval=FALSE--------------------------------------------------------------
#  res <- glm_wrap(dat_hi,
#                  new_covariates = new_cov,
#                  .models = models,
#                  alpha = c(0.01, 0.025, seq(0.05, 0.5, by = 0.05)) * 2)
#  res$forecasts$location <- "15"

## -----------------------------------------------------------------------------
head(res$forecasts)
res$model
res$model$fit
res$model$fit$fitted_model$family
res$model$fit$fitted_model$coefficients

## -----------------------------------------------------------------------------
hi_glm_prepped <- format_for_submission(res$forecasts, method="CREG", format = "legacy")
hi_glm_prepped

## ---- warning=FALSE-----------------------------------------------------------
plot_forecast(dat_hi, hi_glm_prepped$CREG, location="15", pi=.9)

