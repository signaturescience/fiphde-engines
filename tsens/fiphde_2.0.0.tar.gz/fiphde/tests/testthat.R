library(testthat)
library(fiphde)

test_check("fiphde")
